# AICE Associate 실습 자료

[실행 안내](examples/README.md)와 [데이터 사전](examples/data-dictionary.md)을 읽고 examples 폴더에서 실행합니다. 실제 시험 자료가 아닌 자체 학습용 문제입니다.
